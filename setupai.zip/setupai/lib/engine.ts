"use client";

import type { InitProgressReport, MLCEngineInterface } from "@mlc-ai/web-llm";
import type { ChatMessage } from "./types";

type ProgressCallback = (report: InitProgressReport) => void;

let engine: MLCEngineInterface | null = null;
let loadedModelId: string | null = null;
let loadingPromise: Promise<MLCEngineInterface> | null = null;

export function isWebGPUSupported(): boolean {
  if (typeof navigator === "undefined") return false;
  return Boolean((navigator as Navigator & { gpu?: unknown }).gpu);
}

/**
 * Lazily loads (or reuses) the WebLLM engine for a given model.
 * The model weights are fetched from the WebLLM CDN once and cached by the
 * browser's Cache Storage — every call after the first is fully offline.
 */
export async function ensureEngine(
  modelId: string,
  onProgress: ProgressCallback
): Promise<MLCEngineInterface> {
  if (engine && loadedModelId === modelId) return engine;

  if (loadingPromise && loadedModelId === modelId) return loadingPromise;

  const webllm = await import("@mlc-ai/web-llm");

  loadedModelId = modelId;
  loadingPromise = webllm
    .CreateMLCEngine(modelId, {
      initProgressCallback: onProgress,
    })
    .then((created) => {
      engine = created;
      loadingPromise = null;
      return created;
    })
    .catch((err) => {
      loadingPromise = null;
      loadedModelId = null;
      throw err;
    });

  return loadingPromise;
}

export function unloadEngine() {
  engine = null;
  loadedModelId = null;
  loadingPromise = null;
}

export async function* streamChatCompletion(
  modelId: string,
  systemPrompt: string,
  history: ChatMessage[],
  onProgress: ProgressCallback
): AsyncGenerator<string, void, unknown> {
  const eng = await ensureEngine(modelId, onProgress);

  const messages = [
    { role: "system" as const, content: systemPrompt },
    ...history.map((m) => ({ role: m.role, content: m.content })),
  ];

  const stream = await eng.chat.completions.create({
    messages,
    stream: true,
    temperature: 0.7,
    top_p: 0.95,
  });

  for await (const chunk of stream) {
    const delta = chunk.choices?.[0]?.delta?.content;
    if (delta) yield delta;
  }
}

export async function interruptGeneration() {
  if (engine) {
    await engine.interruptGenerate();
  }
}
