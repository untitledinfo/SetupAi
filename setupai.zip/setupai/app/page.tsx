"use client";

import { useEffect, useRef, useState } from "react";
import type { InitProgressReport } from "@mlc-ai/web-llm";
import Sidebar from "@/components/Sidebar";
import Composer from "@/components/Composer";
import MessageBubble from "@/components/MessageBubble";
import ModelLoader from "@/components/ModelLoader";
import { MODEL_OPTIONS, DEFAULT_MODEL_ID, DEFAULT_SYSTEM_PROMPT } from "@/lib/models";
import { loadConversations, saveConversations, newId } from "@/lib/storage";
import { streamChatCompletion, interruptGeneration, isWebGPUSupported } from "@/lib/engine";
import type { ChatMessage, Conversation, EngineStatus } from "@/lib/types";
import { Settings2, Download, RotateCcw } from "lucide-react";

function makeConversation(modelId: string): Conversation {
  const now = Date.now();
  return {
    id: newId(),
    title: "New chat",
    systemPrompt: DEFAULT_SYSTEM_PROMPT,
    modelId,
    messages: [],
    createdAt: now,
    updatedAt: now,
  };
}

export default function Page() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [status, setStatus] = useState<EngineStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const initializedRef = useRef(false);

  const active = conversations.find((c) => c.id === activeId) ?? null;

  // Load persisted conversations once on mount.
  useEffect(() => {
    if (initializedRef.current) return;
    initializedRef.current = true;

    if (!isWebGPUSupported()) {
      setStatus("unsupported");
    }

    const stored = loadConversations();
    if (stored.length > 0) {
      setConversations(stored);
      setActiveId(stored.slice().sort((a, b) => b.updatedAt - a.updatedAt)[0].id);
    } else {
      const c = makeConversation(DEFAULT_MODEL_ID);
      setConversations([c]);
      setActiveId(c.id);
    }
  }, []);

  useEffect(() => {
    if (conversations.length > 0) saveConversations(conversations);
  }, [conversations]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [active?.messages.length, active?.messages[active.messages.length - 1]?.content]);

  const updateConversation = (id: string, patch: Partial<Conversation>) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...patch, updatedAt: Date.now() } : c))
    );
  };

  const handleNewChat = () => {
    const modelId = active?.modelId ?? DEFAULT_MODEL_ID;
    const c = makeConversation(modelId);
    setConversations((prev) => [c, ...prev]);
    setActiveId(c.id);
  };

  const handleDelete = (id: string) => {
    setConversations((prev) => {
      const next = prev.filter((c) => c.id !== id);
      if (id === activeId) {
        setActiveId(next[0]?.id ?? null);
      }
      return next;
    });
  };

  const handleModelChange = (modelId: string) => {
    if (!active) return;
    updateConversation(active.id, { modelId });
  };

  const onProgress = (report: InitProgressReport) => {
    const text = report.text ?? "";
    setProgressText(text);
    if (typeof report.progress === "number") setProgress(report.progress);
    if (/download/i.test(text)) setStatus("downloading");
    else if (/compil|load/i.test(text)) setStatus("compiling");
  };

  const runGeneration = async (conversation: Conversation, messages: ChatMessage[]) => {
    setIsGenerating(true);
    setStatus((s) => (s === "unsupported" ? s : "downloading"));

    const assistantMsg: ChatMessage = {
      id: newId(),
      role: "assistant",
      content: "",
      createdAt: Date.now(),
    };

    updateConversation(conversation.id, {
      messages: [...messages, assistantMsg],
    });

    try {
      let acc = "";
      for await (const delta of streamChatCompletion(
        conversation.modelId,
        conversation.systemPrompt,
        messages,
        onProgress
      )) {
        acc += delta;
        setStatus("generating");
        setConversations((prev) =>
          prev.map((c) =>
            c.id === conversation.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsg.id ? { ...m, content: acc } : m
                  ),
                }
              : c
          )
        );
      }
      setStatus("ready");
    } catch (err) {
      setStatus("error");
      const message =
        err instanceof Error ? err.message : "Generation was interrupted or failed.";
      setConversations((prev) =>
        prev.map((c) =>
          c.id === conversation.id
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === assistantMsg.id && !m.content
                    ? { ...m, content: `_${message}_` }
                    : m
                ),
              }
            : c
        )
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSend = async (text: string) => {
    if (!active) return;

    const userMsg: ChatMessage = {
      id: newId(),
      role: "user",
      content: text,
      createdAt: Date.now(),
    };
    const nextMessages = [...active.messages, userMsg];
    const isFirst = active.messages.length === 0;

    updateConversation(active.id, {
      messages: nextMessages,
      title: isFirst ? text.slice(0, 40) : active.title,
    });

    await runGeneration({ ...active, messages: nextMessages }, nextMessages);
  };

  const handleStop = async () => {
    await interruptGeneration();
    setIsGenerating(false);
    setStatus("ready");
  };

  const handleRegenerate = async () => {
    if (!active || active.messages.length === 0) return;
    const trimmed = [...active.messages];
    while (trimmed.length && trimmed[trimmed.length - 1].role === "assistant") trimmed.pop();
    if (!trimmed.length) return;
    updateConversation(active.id, { messages: trimmed });
    await runGeneration({ ...active, messages: trimmed }, trimmed);
  };

  const handleExport = () => {
    if (!active) return;
    const md = active.messages
      .map((m) => `### ${m.role === "user" ? "You" : "SetupAI"}\n\n${m.content}`)
      .join("\n\n---\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${active.title || "setupai-chat"}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const activeModel = MODEL_OPTIONS.find((m) => m.id === active?.modelId) ?? MODEL_OPTIONS[0];
  const engineBusy = status === "downloading" || status === "compiling";

  return (
    <main className="flex h-screen overflow-hidden">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        onSelect={setActiveId}
        onNew={handleNewChat}
        onDelete={handleDelete}
        models={MODEL_OPTIONS}
        activeModelId={active?.modelId ?? DEFAULT_MODEL_ID}
        onModelChange={handleModelChange}
        disabled={isGenerating}
      />

      <section className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-ink-600 flex items-center justify-between px-5 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-sm text-steel-200 truncate">{active?.title ?? "SetupAI"}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full border border-ink-600 text-steel-400 font-mono">
              {activeModel.label}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleExport}
              disabled={!active?.messages.length}
              className="w-8 h-8 rounded-lg hover:bg-ink-800 text-steel-400 hover:text-steel-100 flex items-center justify-center disabled:opacity-30 transition-colors"
              aria-label="Export chat"
              title="Export chat as Markdown"
            >
              <Download size={15} />
            </button>
            <button
              onClick={handleRegenerate}
              disabled={!active?.messages.length || isGenerating}
              className="w-8 h-8 rounded-lg hover:bg-ink-800 text-steel-400 hover:text-steel-100 flex items-center justify-center disabled:opacity-30 transition-colors"
              aria-label="Regenerate last response"
              title="Regenerate last response"
            >
              <RotateCcw size={15} />
            </button>
            <button
              onClick={() => setShowSettings((s) => !s)}
              className={`w-8 h-8 rounded-lg hover:bg-ink-800 flex items-center justify-center transition-colors ${
                showSettings ? "text-volt-400 bg-ink-800" : "text-steel-400 hover:text-steel-100"
              }`}
              aria-label="Settings"
              title="System prompt settings"
            >
              <Settings2 size={15} />
            </button>
          </div>
        </header>

        {showSettings && active && (
          <div className="border-b border-ink-600 bg-ink-900/60 px-5 py-3">
            <label className="text-[11px] uppercase tracking-wide text-steel-400 mb-1.5 block">
              System prompt
            </label>
            <textarea
              value={active.systemPrompt}
              onChange={(e) => updateConversation(active.id, { systemPrompt: e.target.value })}
              rows={2}
              className="w-full bg-ink-800 border border-ink-600 rounded-lg text-sm text-steel-100 px-3 py-2 focus:border-volt-500 focus:outline-none resize-none"
            />
          </div>
        )}

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-5">
          {!active || active.messages.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              {status === "unsupported" ? (
                <ModelLoader status={status} progress={0} text="" modelLabel={activeModel.label} />
              ) : engineBusy ? (
                <ModelLoader
                  status={status}
                  progress={progress}
                  text={progressText}
                  modelLabel={activeModel.label}
                />
              ) : (
                <div className="text-center max-w-sm">
                  <h2 className="font-display text-xl text-steel-100 mb-2">
                    Ask SetupAI anything
                  </h2>
                  <p className="text-sm text-steel-400 leading-relaxed">
                    The model loads once into your browser and then runs completely offline —
                    no API key, no account, no server round-trip.
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="max-w-3xl mx-auto py-6 space-y-6">
              {active.messages.map((m) => (
                <MessageBubble key={m.id} message={m} />
              ))}
              {engineBusy && (
                <ModelLoader
                  status={status}
                  progress={progress}
                  text={progressText}
                  modelLabel={activeModel.label}
                />
              )}
            </div>
          )}
        </div>

        <Composer
          onSend={handleSend}
          onStop={handleStop}
          isGenerating={isGenerating}
          disabled={status === "unsupported"}
        />
      </section>
    </main>
  );
}
