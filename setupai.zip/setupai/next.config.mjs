/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // WebLLM loads WASM + web workers; these headers enable SharedArrayBuffer,
  // which some backends use for faster in-browser inference.
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
          { key: "Cross-Origin-Embedder-Policy", value: "credentialless" },
        ],
      },
    ];
  },
  webpack: (config) => {
    config.resolve.fallback = { ...config.resolve.fallback, fs: false };
    return config;
  },
};

export default nextConfig;
